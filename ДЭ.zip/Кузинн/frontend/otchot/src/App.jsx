import React from 'react';
import styles from './App.module.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Head from './Components/main/head.jsx';
import Body from './Components/main/body.jsx';
import Footer from './Components/main/footer.jsx';
import Login from './Components/registration/login.jsx';
import Registration from './Components/registration/registration.jsx';

function App() {
  return (
    <div className={styles.app}>
      <Head />
      <main>
        <Routes>
          <Route path="/" element={<Body />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registration" element={<Registration />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;