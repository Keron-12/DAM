import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { registration } from '../Http/userAPI';  
import Swal from 'sweetalert2';
import styles from './Registration.module.css';

function Registration() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        fullname: '',
        phone: '',
    });

    const [errors, setErrors] = useState({
        email: '',
        password: '',
        fullname: '',
        phone: '',
    });

    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
        // Очищаем ошибку при изменении поля
        if (errors[id]) setErrors(prev => ({ ...prev, [id]: '' }));
    };

    const validateForm = () => {
        let isValid = true;
        const newErrors = { email: '', password: '', fullname: '', phone: '' };

        if (!formData.email.trim()) {
            newErrors.email = 'Email обязателен';
            isValid = false;
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'Некорректный email';
            isValid = false;
        }

        if (!formData.password) {
            newErrors.password = 'Пароль обязателен';
            isValid = false;
        } else if (formData.password.length < 4) {
            newErrors.password = 'Минимум 4 символа';
            isValid = false;
        }

        if (!formData.fullname.trim()) {
            newErrors.fullname = 'ФИО обязательно';
            isValid = false;
        } else if (!/^[А-Яа-яЁё\s]+$/.test(formData.fullname)) {
            newErrors.fullname = 'Только кириллица и пробелы';
            isValid = false;
        }

        if (!formData.phone) {
            newErrors.phone = 'Телефон обязателен';
            isValid = false;
        } else if (!/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/.test(formData.phone)) {
            newErrors.phone = 'Формат: +7(000)-000-00-00';
            isValid = false;
        }

        setErrors(newErrors);
        return isValid;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) return;
        
        setIsLoading(true);

        try {
            // Проверяем, есть ли уже такой пользователь
            const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];
            if (registeredUsers.some(user => user.email === formData.email)) {
                throw new Error('Пользователь с таким email уже существует');
            }

            const response = await registration(
                formData.email, 
                formData.password, 
                formData.fullname, 
                formData.phone
            );
            
            const token = response.data.token;
            const [fname, lname] = formData.fullname.split(' ');

            // Сохраняем пользователя
            registeredUsers.push({
                email: formData.email,
                password: formData.password,
                roles: 'user',
            });

            localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
            localStorage.setItem('firstname', fname);
            localStorage.setItem('lastname', lname || '');
            localStorage.setItem('token', token);

            await Swal.fire({
                icon: 'success',
                title: 'Регистрация успешна!',
                text: 'Вы успешно зарегистрированы как пользователь',
                confirmButtonText: 'OK',
                confirmButtonColor: '#4f46e5',
                backdrop: `
                    rgba(79, 70, 229, 0.1)
                    url("/images/nyan-cat.gif")
                    center top
                    no-repeat
                `
            });

            navigate('/login');
        } catch (error) {
            console.error("Registration error:", error);
            await Swal.fire({
                icon: 'error',
                title: 'Ошибка регистрации',
                text: error.message || 'Не удалось зарегистрироваться. Попробуйте позже.',
                confirmButtonText: 'OK',
                confirmButtonColor: '#d33',
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className={styles.registrationBackground}>
            <div className={styles.registrationContainer}>
                <div className={styles.registrationHeader}>
                    <h1 className={styles.registrationTitle}>Создать аккаунт</h1>
                    <p className={styles.registrationSubtitle}>Заполните форму для регистрации</p>
                </div>

                <form onSubmit={handleSubmit} className={styles.registrationForm}>
                    <div className={styles.formGroup}>
                        <label htmlFor="email" className={styles.inputLabel}>Электронная почта</label>
                        <input
                            type="email"
                            id="email"
                            value={formData.email}
                            onChange={handleChange}
                            className={`${styles.formInput} ${errors.email ? styles.inputError : ''}`}
                            placeholder="example@mail.ru"
                        />
                        {errors.email && <span className={styles.errorMessage}>{errors.email}</span>}
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="password" className={styles.inputLabel}>Пароль</label>
                        <input
                            type="password"
                            id="password"
                            value={formData.password}
                            onChange={handleChange}
                            className={`${styles.formInput} ${errors.password ? styles.inputError : ''}`}
                            placeholder="Минимум 4 символа"
                        />
                        {errors.password && <span className={styles.errorMessage}>{errors.password}</span>}
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="fullname" className={styles.inputLabel}>ФИО</label>
                        <input
                            type="text"
                            id="fullname"
                            value={formData.fullname}
                            onChange={handleChange}
                            className={`${styles.formInput} ${errors.fullname ? styles.inputError : ''}`}
                            placeholder="Иванов Иван Иванович"
                        />
                        {errors.fullname && <span className={styles.errorMessage}>{errors.fullname}</span>}
                    </div>

                    <div className={styles.formGroup}>
                        <label htmlFor="phone" className={styles.inputLabel}>Телефон</label>
                        <input
                            type="text"
                            id="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className={`${styles.formInput} ${errors.phone ? styles.inputError : ''}`}
                            placeholder="+7(000)-000-00-00"
                        />
                        {errors.phone && <span className={styles.errorMessage}>{errors.phone}</span>}
                    </div>

                    <button 
                        type="submit" 
                        className={styles.submitButton}
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <span className={styles.spinner}></span>
                        ) : 'Зарегистрироваться'}
                    </button>
                </form>

                <div className={styles.registrationFooter}>
                    <span className={styles.footerText}>Уже есть аккаунт?</span>
                    <Link to="/login" className={styles.footerLink}>Войти</Link>
                </div>
            </div>
        </div>
    );
}

export default Registration;