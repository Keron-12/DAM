import React, { useState } from 'react';
import styles from './Login.module.css'; 
import { Link, useNavigate } from 'react-router-dom'; 
import Swal from 'sweetalert2';

function Login() {
    const [email, setEmail] = useState(''); 
    const [password, setPassword] = useState(''); 
    const [emailError, setEmailError] = useState(''); 
    const [passwordError, setPasswordError] = useState(''); 
    const [isLoading, setIsLoading] = useState(false);

    const navigate = useNavigate();
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];

    const handleSubmit = (event) => {
        event.preventDefault();
        setIsLoading(true);
    
        setEmailError(''); 
        setPasswordError(''); 
    
        let valid = true; 
        let roles = 'user';
    
        // Сначала проверяем администратора
        if (email === 'admin@mail.ru' && password === 'ad123') {
            roles = 'admin';
        } else {
            // Если не администратор, проверяем обычных пользователей
            const user = registeredUsers.find(user => user.email === email);
            
            if (!user) {
                setEmailError('Пользователь с таким email не найден');
                valid = false;
            } else if (user.password !== password) {
                setPasswordError('Неверный пароль');
                valid = false;
            }
        }
    
        if (valid) {
            setTimeout(() => {
                localStorage.setItem('email', email);
                localStorage.setItem('role', roles);
                
                Swal.fire({
                    icon: 'success',
                    title: 'Успешный вход',
                    text: `Добро пожаловать, ${email.split('@')[0]}!`,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#4f46e5',
                    backdrop: `
                        rgba(79, 70, 229, 0.1)
                        url("/images/nyan-cat.gif")
                        center top
                        no-repeat
                    `
                }).then(() => {
                    navigate('/');
                });
                setIsLoading(false);
            }, 1000);
        } else {
            setIsLoading(false);
        }
    };

    return (
        <div className={styles.loginBackground}>
            <div className={styles.loginContainer}>
                <div className={styles.loginHeader}>
                    <h1 className={styles.loginTitle}>Вход в систему</h1>
                    <p className={styles.loginSubtitle}>Введите свои учетные данные для доступа к аккаунту</p>
                </div>
                
                <form onSubmit={handleSubmit} className={styles.loginForm}>
                    <div className={styles.formGroup}>
                        <label htmlFor="email" className={styles.inputLabel}>Электронная почта</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className={`${styles.formInput} ${emailError ? styles.inputError : ''}`}
                            placeholder="example@mail.ru"
                        />
                        {emailError && <span className={styles.errorMessage}>{emailError}</span>}
                    </div>
                    
                    <div className={styles.formGroup}>
                        <label htmlFor="password" className={styles.inputLabel}>Пароль</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className={`${styles.formInput} ${passwordError ? styles.inputError : ''}`}
                            placeholder="••••••••"
                        />
                        {passwordError && <span className={styles.errorMessage}>{passwordError}</span>}
                    </div>
                    
                    <button 
                        type="submit" 
                        className={styles.submitButton}
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <span className={styles.spinner}></span>
                        ) : 'Войти'}
                    </button>
                </form>
                
                <div className={styles.loginFooter}>
                    <span className={styles.footerText}>Еще нет аккаунта?</span>
                    <Link to="/registration" className={styles.footerLink}>Зарегистрироваться</Link>
                </div>
            </div>
        </div>
    );
}

export default Login;