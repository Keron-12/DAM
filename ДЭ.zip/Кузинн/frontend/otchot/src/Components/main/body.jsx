import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Body.module.css';
import Img from '../../assets/img/otchots.png';
import Img2 from '../../assets/img/sotrudnik.png';
import Img3 from '../../assets/img/information.png';
import Img4 from '../../assets/img/usluga.png';

function Body() {
    const cards = [
        {
            title: "Отчеты",
            description: "Здесь можно найти все отчеты",
            img: Img,
            link: "/reports",
            imgClass: styles.otchotImg
        },
        {
            title: "Сотрудники",
            description: "Информация о сотрудниках компании",
            img: Img2,
            link: "/workers",
            imgClass: styles.sotrudnikImg
        },
        {
            title: "О компании",
            description: "Данные о нашей компании",
            img: Img3,
            link: "/company-info",
            imgClass: styles.informationImg
        },
        {
            title: "Услуги",
            description: "Описание всех предоставляемых услуг",
            img: Img4,
            link: "/services",
            imgClass: styles.uslugaImg
        }
    ];

    return (
        <section className={styles.reportContainer}>
            {cards.map((card, index) => (
                <article key={index} className={styles.card}>
                    <Link to={card.link} className={styles.cardLink}>
                        <div className={styles.imgContainer}>
                            <img src={card.img} alt={card.title} className={card.imgClass} />
                        </div>
                        <div className={styles.cardContent}>
                            <h3>{card.title}</h3>
                            <p>{card.description}</p>
                            <span className={styles.linkText}>Подробнее →</span>
                        </div>
                    </Link>
                </article>
            ))}
        </section>
    );
}

export default Body;