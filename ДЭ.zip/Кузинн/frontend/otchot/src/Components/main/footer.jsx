import React from 'react';
import styles from './Footer.module.css';

function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={styles.footerContent}>
                <h2 className={styles.footerTitle}>Контакты компании</h2>
                <div className={styles.contactInfo}>
                    <div className={styles.contactItem}>
                        <span className={styles.contactLabel}>Телефон:</span>
                        <a href="tel:+79773007532">+7 (977) 300-75-32</a>
                    </div>
                    <div className={styles.contactItem}>
                        <span className={styles.contactLabel}>Email:</span>
                        <a href="mailto:info@company.com">info@company.com</a>
                    </div>
                    <div className={styles.contactItem}>
                        <span className={styles.contactLabel}>Адрес:</span>
                        <span>г. Москва, ул. Примерная, д. 1</span>
                    </div>
                </div>
                <div className={styles.copyright}>
                    © {new Date().getFullYear()} Название компании. Все права защищены.
                </div>
            </div>
        </footer>
    );
}

export default Footer;