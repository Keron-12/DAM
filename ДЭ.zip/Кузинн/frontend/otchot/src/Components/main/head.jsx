import React from 'react';
import styles from './Head.module.css';
import { Link } from 'react-router-dom';

function Head() {
    return (
        <header className={styles.header}>
            <div className={styles.headerContent}>
                <h1 className={styles.title}>Система корпоративной отчетности</h1>
                <nav className={styles.nav}>
                    <Link to="/" className={styles.navLink}>Главная</Link>
                    <Link to="/registration" className={styles.navLink}>Регистрация</Link>
                    <Link to="/login" className={styles.navLink}>Вход</Link>
                </nav>
            </div>
        </header>
    );
}

export default Head;