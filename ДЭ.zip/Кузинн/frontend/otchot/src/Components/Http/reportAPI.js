import {$authHost, $host} from "./index";

export const reportp = async (reportsname, reportsnumber) => {
    const response = await $host.post('api/report/reportp', {reportsname, reportsnumber})
    return response
}

export const reportg = async (reportsnumber) => {
    const response = await $host.get(`api/report/reportg?reportsnumber=${reportsnumber}`);
    return response;
}

export const reportd = async (id) => {
    const response = await $authHost.delete(`api/report/reportd/${id}`);
    return response;
}