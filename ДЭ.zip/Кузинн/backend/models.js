const sequelize = require('./db')
const { DataTypes } = require('sequelize')

const Users = sequelize.define('users', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING, allowNull: false },
    number_phone: { type: DataTypes.TEXT, allowNull: false, unique: true},
    password: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, unique: true },
    role: { type: DataTypes.STRING, defaultValue: "USER" }
})

const Workers = sequelize.define('workers', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    email: { type: DataTypes.STRING, allowNull: false },
    number_phone: { type: DataTypes.TEXT, allowNull: false },
    workers_name: { type: DataTypes.STRING, allowNull: false },
    workers_image: { type: DataTypes.STRING, allowNull: false }
})

const Reports = sequelize.define('reports', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    reportsnumber: { type: DataTypes.TEXT, allowNull: false },
    reportsname: { type: DataTypes.STRING, allowNull: false },
})

const Comments = sequelize.define('comments', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    user_name: { type: DataTypes.STRING, allowNull: false },
    status: { type: DataTypes.STRING, allowNull: false }
})

Users.hasMany(Reports);
Reports.belongsTo(Users);

Users.hasMany(Comments);
Comments.belongsTo(Users);

Users.hasOne(Workers);
Workers.belongsTo(Users);

Workers.hasMany(Reports);
Reports.belongsTo(Workers);

module.exports = {
    Users,
    Comments,
    Workers,
    Reports
}